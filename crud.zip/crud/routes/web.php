<?php

use App\Http\Controllers\crudcontroller;
use Illuminate\Support\Facades\Route;

Route::get("/", [crudcontroller::class,"index"])->name("crud.index");

//ruta para añadir un estudiante
Route::post("/registrar-estudiante", [crudcontroller::class,"create"])->name("crud.create");

//ruta para modificar producto
Route::post("/modificar-estudiante", [crudcontroller::class,"update"])->name("crud.update");

//ruta para eliminar
Route::get("/eliminar-estudiante-{id}", [crudcontroller::class,"delete"])->name("crud.delete");